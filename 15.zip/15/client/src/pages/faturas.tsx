import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  Plus, 
  Search, 
  FileText,
  Download,
  Send,
  Eye,
  MoreHorizontal,
  Edit,
  Trash
} from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { StatusBadge } from "@/components/status-badge";
import { useState } from "react";

const mockFaturas = [
  {
    id: 1,
    numero: "FAT-2024-001",
    cliente: "João Silva - ABC Indústria",
    valor: 5200.00,
    emissao: "2024-10-15",
    vencimento: "2024-11-15",
    status: "pendente" as const,
  },
  {
    id: 2,
    numero: "FAT-2024-002",
    cliente: "Pedro Oliveira - Consultoria DEF",
    valor: 8900.00,
    emissao: "2024-10-20",
    vencimento: "2024-11-20",
    status: "pago" as const,
  },
  {
    id: 3,
    numero: "FAT-2024-003",
    cliente: "Maria Santos - XYZ Comércio",
    valor: 3500.00,
    emissao: "2024-10-10",
    vencimento: "2024-11-10",
    status: "pago" as const,
  },
  {
    id: 4,
    numero: "FAT-2024-004",
    cliente: "João Silva - ABC Indústria",
    valor: 6200.00,
    emissao: "2024-10-25",
    vencimento: "2024-11-25",
    status: "agendado" as const,
  },
];

export default function Faturas() {
  const [searchTerm, setSearchTerm] = useState("");

  const filteredFaturas = mockFaturas.filter(fatura =>
    fatura.numero.toLowerCase().includes(searchTerm.toLowerCase()) ||
    fatura.cliente.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="flex-1 space-y-6 p-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Faturas</h1>
          <p className="text-muted-foreground">Emita e gerencie faturas de cobrança</p>
        </div>
        <Button data-testid="button-new-invoice">
          <Plus className="h-4 w-4 mr-2" />
          Nova Fatura
        </Button>
      </div>

      <div className="grid gap-6 md:grid-cols-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total em Aberto
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold font-mono">R$ 11.400,00</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Recebido
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold font-mono text-success">R$ 12.400,00</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Faturas Pendentes
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">1</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total de Faturas
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">4</div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <CardTitle>Todas as Faturas</CardTitle>
            <div className="relative w-full sm:w-[300px]">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Buscar faturas..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9"
                data-testid="input-search-invoices"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Número</TableHead>
                <TableHead>Cliente</TableHead>
                <TableHead>Emissão</TableHead>
                <TableHead>Vencimento</TableHead>
                <TableHead className="text-right">Valor</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredFaturas.map((fatura) => (
                <TableRow key={fatura.id} data-testid={`invoice-row-${fatura.id}`}>
                  <TableCell className="font-mono font-medium">{fatura.numero}</TableCell>
                  <TableCell>{fatura.cliente}</TableCell>
                  <TableCell className="font-mono text-sm">
                    {new Date(fatura.emissao).toLocaleDateString('pt-BR')}
                  </TableCell>
                  <TableCell className="font-mono text-sm">
                    {new Date(fatura.vencimento).toLocaleDateString('pt-BR')}
                  </TableCell>
                  <TableCell className="text-right font-mono font-semibold">
                    R$ {fatura.valor.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                  </TableCell>
                  <TableCell>
                    <StatusBadge status={fatura.status} />
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button variant="ghost" size="icon" data-testid={`button-view-${fatura.id}`}>
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" data-testid={`button-download-${fatura.id}`}>
                        <Download className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" data-testid={`button-send-${fatura.id}`}>
                        <Send className="h-4 w-4" />
                      </Button>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" data-testid={`button-more-${fatura.id}`}>
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem data-testid={`button-edit-${fatura.id}`}>
                            <Edit className="h-4 w-4 mr-2" />
                            Editar
                          </DropdownMenuItem>
                          <DropdownMenuItem className="text-destructive" data-testid={`button-delete-${fatura.id}`}>
                            <Trash className="h-4 w-4 mr-2" />
                            Excluir
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          {filteredFaturas.length === 0 && (
            <div className="text-center py-12">
              <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">Nenhuma fatura encontrada</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
