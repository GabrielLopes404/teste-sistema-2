import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { 
  Plus, 
  Search, 
  Mail,
  Phone,
  Building2,
  MoreHorizontal,
  Edit,
  Trash
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const mockContatos = [
  {
    id: 1,
    nome: "João Silva",
    empresa: "ABC Indústria Ltda",
    tipo: "cliente",
    email: "joao@abcindustria.com",
    telefone: "(11) 98765-4321",
    cnpj: "12.345.678/0001-90"
  },
  {
    id: 2,
    nome: "Maria Santos",
    empresa: "XYZ Comércio",
    tipo: "fornecedor",
    email: "maria@xyzcomercio.com",
    telefone: "(11) 91234-5678",
    cnpj: "98.765.432/0001-10"
  },
  {
    id: 3,
    nome: "Pedro Oliveira",
    empresa: "Consultoria DEF",
    tipo: "cliente",
    email: "pedro@consultoriadef.com",
    telefone: "(11) 99876-5432",
    cnpj: "45.678.901/0001-23"
  },
  {
    id: 4,
    nome: "Ana Costa",
    empresa: "Fornecedora GHI",
    tipo: "fornecedor",
    email: "ana@fornecedoraghi.com",
    telefone: "(11) 97654-3210",
    cnpj: "78.901.234/0001-56"
  },
];

export default function Contatos() {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterTipo, setFilterTipo] = useState<string>("all");

  const filteredContatos = mockContatos.filter(contato => {
    const matchesSearch = contato.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         contato.empresa.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesTipo = filterTipo === "all" || contato.tipo === filterTipo;
    return matchesSearch && matchesTipo;
  });

  return (
    <div className="flex-1 space-y-6 p-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Contatos</h1>
          <p className="text-muted-foreground">Gerencie clientes e fornecedores</p>
        </div>
        <Button data-testid="button-new-contact">
          <Plus className="h-4 w-4 mr-2" />
          Novo Contato
        </Button>
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <CardTitle>Todos os Contatos</CardTitle>
            <div className="flex flex-wrap gap-2">
              <div className="relative flex-1 min-w-[200px]">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Buscar contatos..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-9"
                  data-testid="input-search-contacts"
                />
              </div>
              <div className="flex gap-2">
                <Button
                  variant={filterTipo === "all" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setFilterTipo("all")}
                  data-testid="filter-all"
                >
                  Todos
                </Button>
                <Button
                  variant={filterTipo === "cliente" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setFilterTipo("cliente")}
                  data-testid="filter-clients"
                >
                  Clientes
                </Button>
                <Button
                  variant={filterTipo === "fornecedor" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setFilterTipo("fornecedor")}
                  data-testid="filter-suppliers"
                >
                  Fornecedores
                </Button>
              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {filteredContatos.map((contato) => (
              <Card key={contato.id} className="hover-elevate" data-testid={`contact-card-${contato.id}`}>
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <Avatar>
                        <AvatarFallback className="bg-primary text-primary-foreground">
                          {contato.nome.split(' ').map(n => n[0]).join('').slice(0, 2)}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <h3 className="font-semibold">{contato.nome}</h3>
                        <Badge variant={contato.tipo === 'cliente' ? 'default' : 'secondary'} className="text-xs">
                          {contato.tipo === 'cliente' ? 'Cliente' : 'Fornecedor'}
                        </Badge>
                      </div>
                    </div>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" data-testid={`button-actions-${contato.id}`}>
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem data-testid={`button-edit-${contato.id}`}>
                          <Edit className="h-4 w-4 mr-2" />
                          Editar
                        </DropdownMenuItem>
                        <DropdownMenuItem className="text-destructive" data-testid={`button-delete-${contato.id}`}>
                          <Trash className="h-4 w-4 mr-2" />
                          Excluir
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                  
                  <div className="space-y-3">
                    <div className="flex items-center gap-2 text-sm">
                      <Building2 className="h-4 w-4 text-muted-foreground" />
                      <span className="truncate">{contato.empresa}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <Mail className="h-4 w-4 text-muted-foreground" />
                      <span className="truncate">{contato.email}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <Phone className="h-4 w-4 text-muted-foreground" />
                      <span>{contato.telefone}</span>
                    </div>
                    <div className="pt-2 border-t">
                      <p className="text-xs text-muted-foreground">CNPJ: {contato.cnpj}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          {filteredContatos.length === 0 && (
            <div className="text-center py-12">
              <p className="text-muted-foreground">Nenhum contato encontrado</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
